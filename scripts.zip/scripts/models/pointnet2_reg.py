from colorsys import yiq_to_rgb
import torch
import torch.nn as nn
import torch.nn.functional as F
from utils.set_abstraction import PointNet_SA_Module
from utils.feature_propagation import PointNet_FP_Module
from torch.distributions import MultivariateNormal as MVN

class pointnet2_reg_pt1(nn.Module):
    def __init__(self, in_channels):
        super(pointnet2_reg_pt1, self).__init__()
        self.pt_sa1 = PointNet_SA_Module(M=512, radius=0.2, K=32, in_channels=in_channels, mlp=[64, 64, 128], group_all=False)
        self.pt_sa2 = PointNet_SA_Module(M=128, radius=0.4, K=64, in_channels=131, mlp=[128, 128, 256], group_all=False)
        self.pt_sa3 = PointNet_SA_Module(M=None, radius=None, K=None, in_channels=259, mlp=[256, 512, 1024], group_all=True)
        self.fc1 = nn.Linear(1024, 512, bias=False)
        self.bn1 = nn.BatchNorm1d(512)
        self.dropout1 = nn.Dropout(0.5)
        self.fc2 = nn.Linear(512, 256, bias=False)
        self.bn2 = nn.BatchNorm1d(256)
        self.dropout2 = nn.Dropout(0.5)
        self.reg = nn.Linear(256, 1)

    def forward(self, xyz, points):
        batchsize = xyz.shape[0]
        new_xyz, new_points = self.pt_sa1(xyz, points)
        new_xyz, new_points = self.pt_sa2(new_xyz, new_points)
        new_xyz, new_points = self.pt_sa3(new_xyz, new_points)
        net = new_points.view(batchsize, -1)
        net = self.dropout1(F.relu(self.bn1(self.fc1(net))))
        net = self.dropout2(F.relu(self.bn2(self.fc2(net))))
        net = self.reg(net)
        net = net.squeeze(-1)
        net = net.to(torch.float32)
        return net


class pointnet2_reg_ptp(nn.Module):
    def __init__(self, in_channels):
        super(pointnet2_reg_ptp, self).__init__()
        # self.pt_sa1 = PointNet_SA_Module(M=512, radius=0.2, K=32, in_channels=in_channels, mlp=[64, 64, 128], group_all=False)
        # self.pt_sa2 = PointNet_SA_Module(M=128, radius=0.4, K=64, in_channels=131, mlp=[128, 128, 256], group_all=False)
        self.pt_sa1 = PointNet_SA_Module(M=512, radius=3, K=32, in_channels=in_channels, mlp=[64, 64, 128], group_all=False)
        self.pt_sa2 = PointNet_SA_Module(M=128, radius=6, K=64, in_channels=131, mlp=[128, 128, 256], group_all=False)
        self.pt_sa3 = PointNet_SA_Module(M=None, radius=None, K=None, in_channels=259, mlp=[256, 512, 1024], group_all=True)

        self.pt_fp1 = PointNet_FP_Module(in_channels=1024+256, mlp=[256, 256], bn=True)
        self.pt_fp2 = PointNet_FP_Module(in_channels=256 + 128, mlp=[256, 128], bn=True)
        self.pt_fp3 = PointNet_FP_Module(in_channels=128 + 6, mlp=[128, 128, 128], bn=True)

        self.conv1 = nn.Conv1d(128, 128, 1, stride=1, bias=False)
        self.bn1 = nn.BatchNorm1d(128)
        self.dropout1 = nn.Dropout(0.5)
        self.conv2 = nn.Conv1d(128, 1, 1, stride=1)

    def forward(self, l0_xyz, l0_points):
        l1_xyz, l1_points = self.pt_sa1(l0_xyz, l0_points)
        l2_xyz, l2_points = self.pt_sa2(l1_xyz, l1_points)
        l3_xyz, l3_points = self.pt_sa3(l2_xyz, l2_points)

        l2_points = self.pt_fp1(l2_xyz, l3_xyz, l2_points, l3_points)
        l1_points = self.pt_fp2(l1_xyz, l2_xyz, l1_points, l2_points)
        l0_points = self.pt_fp3(l0_xyz, l1_xyz, torch.cat([l0_points, l0_xyz], dim=-1), l1_points)

        net = l0_points.permute(0, 2, 1).contiguous()
        net = self.dropout1(F.relu(self.bn1(self.conv1(net))))
        net = self.conv2(net)
        # net = net.squeeze(1)
        net = net.squeeze(1)
        net = net.squeeze(1)
        return net


class reg_loss(nn.Module):
    def __init__(self):
        super(reg_loss, self).__init__()
        self.loss = nn.MSELoss()
    def forward(self, pred, gt):
        '''

        :param pred: shape=(B, )
        :param y: shape=(B, )
        :return: loss
        '''
        loss = self.loss(pred, gt)
        return loss

def bmc_loss(pred, target, noise_var):
    #! new revised, reshape the input size seems as [batch, 1]:
    pred = torch.reshape(pred, (-1,1))
    target = torch.reshape(target, (-1,1))
    #! end


    logits = - (pred - target.T).pow(2) / (2 * noise_var)# 这个变量很大
    loss = F.cross_entropy(logits, torch.arange(pred.shape[0]).to(noise_var.device))
    
    loss = loss * (2 * noise_var).detach()

    return loss

def bmc_loss_md(pred, target, noise_var):
    I = torch.eye(pred.shape[-1]).to(noise_var.device)
    logits = MVN(pred.unsqueeze(1), noise_var*I).log_prob(target.unsqueeze(0))
    loss = F.cross_entropy(logits, torch.arange(pred.shape[0]).to(noise_var.device))
    loss = loss * (2 * noise_var).detach()

    return loss

class BMCLoss(nn.Module):
    def __init__(self, init_noise_sigma):
        super(BMCLoss, self).__init__()
        self.noise_sigma = torch.nn.Parameter(torch.tensor(init_noise_sigma))

    def forward(self, pred , target):
        noise_var = self.noise_sigma ** 2
        return bmc_loss(pred, target, noise_var)

class BMCLoss_mixed(nn.Module):
    def __init__(self, init_noise_sigma):
        super(BMCLoss_mixed, self).__init__()
        self.noise_sigma = torch.nn.Parameter(torch.tensor(init_noise_sigma))
        self.mseloss = nn.MSELoss()
    def forward(self, pred , target):
        noise_var = self.noise_sigma ** 2
        bmse = bmc_loss(pred, target, noise_var)
        mse = self.mseloss(pred, target)
        loss = bmse + mse
        return loss


if __name__ == '__main__':
    xyz = torch.randn(16, 2048, 3)
    points = torch.randn(16, 2048, 3)
    label = torch.randint(0, 40, size=(16, ))
    reg_model = pointnet2_reg_pt1(6)

    print(reg_model)
    #net = ssg_model(xyz, points)
    #print(net.shape)
    #print(label.shape)
    #loss = cls_loss()
    #loss = loss(net, label)
    #print(loss)